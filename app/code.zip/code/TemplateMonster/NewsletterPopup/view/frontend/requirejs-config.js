var config = {
    map: {
        '*': {
            'newsletterPopup': 'TemplateMonster_NewsletterPopup/js/popup'
        }
    }
};