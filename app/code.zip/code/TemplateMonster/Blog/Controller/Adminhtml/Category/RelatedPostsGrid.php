<?php

namespace TemplateMonster\Blog\Controller\Adminhtml\Category;

class RelatedPostsGrid extends RelatedPosts
{
}
