<?php

namespace TemplateMonster\Blog\Controller\Adminhtml\Post;

class RelatedCommentsGrid extends RelatedComments
{
}
