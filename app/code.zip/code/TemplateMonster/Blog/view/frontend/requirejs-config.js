
var config = {
    map: {
        '*': {}
    },
    paths: {
        "blogCarousel":           "TemplateMonster_Blog/js/blog-carousel",
        "categoriesListCollapse": "TemplateMonster_Blog/js/categories-list-collapse",
        "blogOwlCarousel":        "TemplateMonster_Blog/js/owl.carousel"
    },
    shim: {
        "blogOwlCarousel":  ["jquery"]
    }
};

