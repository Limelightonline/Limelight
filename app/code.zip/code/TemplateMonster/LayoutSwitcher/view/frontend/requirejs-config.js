var config = {
    map: {
        '*': {}
    },
    paths: {
        "customizationTool": "TemplateMonster_LayoutSwitcher/js/customization-tool"
    }
};