<?php

namespace TemplateMonster\LayoutSwitcher\Controller;

use Magento\Framework\App\Action\Action;

/**
 * Index base abstract action.
 *
 * @package TemplateMonster\LayoutSwitcher\Controller
 */
abstract class Index extends Action
{

}