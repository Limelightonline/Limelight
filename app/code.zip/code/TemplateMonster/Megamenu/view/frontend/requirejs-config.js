
var config = {

	map: {
        '*': {}
    },
    paths: {
        "megamenu":     "TemplateMonster_Megamenu/js/megamenu"
    }
};