var config = {
    map: {
        '*': {
            tm_configurator: 'TemplateMonster_Megamenu/js/configurator',
            jquery_ui_1_11_4: "TemplateMonster_Megamenu/js/jquery-ui.1.11.4"
        }
    },
    path: {
        "jquery_ui_1_11_4": "TemplateMonster_Megamenu/js/jquery-ui.1.11.4"
    }
};