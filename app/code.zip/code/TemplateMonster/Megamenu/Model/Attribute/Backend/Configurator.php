<?php
namespace TemplateMonster\Megamenu\Model\Attribute\Backend;

class Configurator extends \Magento\Eav\Model\Entity\Attribute\Backend\AbstractBackend
{

}
