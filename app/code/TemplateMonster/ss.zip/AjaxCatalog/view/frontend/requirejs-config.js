var config = {
    map: {
        '*': {
            productListToolbarForm : 'TemplateMonster_AjaxCatalog/js/tm-catalog-ajax'
        }
    }
};